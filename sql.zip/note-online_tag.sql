CREATE DATABASE  IF NOT EXISTS `note-online` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `note-online`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 47.98.191.32    Database: note-online
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '笔记标签',
  `tag_name` varchar(100) NOT NULL COMMENT '标签名',
  `creator` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_date` datetime NOT NULL COMMENT '创建日期',
  `modify_date` datetime DEFAULT NULL COMMENT '修改日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (2,'maven','Gemu','2017-10-30 17:55:56',NULL),(3,'git','Gemu','2017-11-05 22:12:04',NULL),(4,'node','Gemu','2017-11-07 11:35:37',NULL),(5,'gitlab','Gemu','2017-11-07 14:18:05',NULL),(6,'mysql','Gemu','2017-11-07 15:25:48',NULL),(7,'nginx','Gemu','2017-11-07 23:30:13',NULL),(8,'linux','Gemu','2017-11-12 17:00:48',NULL),(9,'MongoDB','Gemu','2017-12-18 11:48:40',NULL),(10,'python','Gemu','2017-12-18 16:38:59',NULL),(11,'SQL','Gemu','2018-01-05 16:15:32',NULL),(12,'javascript','Gemu','2018-01-16 15:28:59',NULL),(13,'spring','Gemu','2018-01-17 14:44:31',NULL),(14,'docker','Gemu','2018-03-02 16:36:16',NULL),(15,'mybatis','Gemu','2018-03-24 13:22:35',NULL),(16,'springboot','Gemu','2018-03-26 09:25:36',NULL),(17,'canvas','Gemu','2018-04-04 20:40:19',NULL),(18,'spring cloud','Gemu','2018-04-21 12:45:33',NULL),(19,'redis','Gemu','2018-05-15 03:38:07',NULL);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-03 11:05:30
